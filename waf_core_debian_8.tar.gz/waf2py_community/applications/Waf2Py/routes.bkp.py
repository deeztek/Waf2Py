

default_controller = 'default'
default_function = 'index'



routers = dict(
    BASE = dict(
        default_application='Waf2Py',
    )
)

routes_onerror = [
     (r'Waf2Py/400', r'/Waf2Py/default/index')
    ,(r'Waf2Py/*', r'/Waf2Py/default/index')
    ,(r'Waf2Py/*', r'/Waf2Py/default/index')
    ,(r'*/404', r'/Waf2Py/default/index')
    ,(r'*/*', r'/Waf2Py/default/index')
 ]
