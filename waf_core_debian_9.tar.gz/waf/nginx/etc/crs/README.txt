********* OWASP CRS 2.2.9 ***********
This CRS version work, perfect with modsecurity nginx refactored 2.2.9 (actually using),
but they have missing info in their rules and catch more false positive. they need to be adapted a bit.

******** OWASP CRS 3.0 **********
Wokrs fine with modsecurity nginx refactored 2.2.9 (actually using), but it can have memory problems, ex:
a rule who is supposed to catch a GET or HEAD request catch a POST request.
However, this CRS is more accurate and they don't have missing information.

in this version we use crs 2.2.9, and we've changed some info, like: put missing classifications.

if you want to use another crs version, just put it in here and name it "owasp-modsecurity-crs"


Cheers.
Chris.
